import { RecentSalesSkeleton } from '@/features/overview/components/recent-sales-skeleton';
import React from 'react';

export default function Loading() {
  return <RecentSalesSkeleton />;
}
